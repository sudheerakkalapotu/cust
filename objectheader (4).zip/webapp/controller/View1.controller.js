sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("objectheader.controller.View1", {
		    onSearch : function()
		    {
		    	this.getView().byId("idPanel").setExpanded(false);
		    },
		    handleSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
 
		handleClose: function(oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				this.getView().byId("inpAccNo").setValue(aContexts[0].getObject().ProductId);
			}
			oEvent.getSource().getBinding("items").filter([]);
			this.getView().byId("idpiechart").getModel().refresh();
		},
			handleCloseBP: function(oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				this.getView().byId("inpHeaderBP").setValue(aContexts[0].getObject().ProductId);
			}
			oEvent.getSource().getBinding("items").filter([]);
			this.getView().byId("idpiechart").getModel().refresh();
		},
				    handleValueHelpBP : function(oEvent)
		    {
		    	if (! this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("objectheader.fragment.BPDialog", this);
				}
 
			// Multi-select if required
		     
		//	this.getView().addDependent(this._oDialog);
 
			// toggle compact style
		//	jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			
				var data = {
	"ProductCollection": [
		{
			"ProductId": "1000000183",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1000000450",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "12543",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1000000452",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1000000455",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "1000000458",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1000000459",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
		
	
		]
	};

var jsonmodel = new sap.ui.model.json.JSONModel();
jsonmodel.setData(data);
this._oDialog.setModel(jsonmodel);
			
			
			
			this._oDialog.open();
		    },
		    handleValueHelp : function(oEvent)
		    {
		    	if (! this._oDialogBP) {
				this._oDialogBP = sap.ui.xmlfragment("objectheader.fragment.Dialog", this);
				}
 
			// Multi-select if required
		     
		//	this.getView().addDependent(this._oDialog);
 
			// toggle compact style
		//	jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			
				var data = {
	"ProductCollection": [
		{
			"ProductId": "421000027266",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "421000027267",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "12543",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "421000027270",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "421000027356",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "421000027789",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "421000027876",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "421000027365",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "421000027463",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "421000027259",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "421000027912",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		}
		
	
		]
	};

var jsonmodel = new sap.ui.model.json.JSONModel();
jsonmodel.setData(data);
this._oDialogBP.setModel(jsonmodel);
			
			
			
			this._oDialogBP.open();
		    },
			onInit : function()
			{
				
				var data = {
	"ProductCollection": [
		{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "12/15/2016",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "12543",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		},
		
			{
			"ProductId": "1/05/2017",
			"Category": "Laptops",
			"MainCategory": "Computer Systems",
			"TaxTarifCode": "1",
			"SupplierName": "15000",
			"WeightMeasure": "$25,000",
			"WeightUnit": "$1,250",
			"Description": "Notebook Basic 15 with 2,80 GHz quad core, 15\" LCD, 4 GB DDR3 RAM, 500 GB Hard Disc, Windows 8 Pro",
			"Name": "Notebook Basic 15",
			"ProductPicUrl": "test-resources/sap/ui/demokit/explored/img/HT-1000.jpg",
			"Status": "Available",
			"Quantity": 10,
			"UoM": "PC",
			"CurrencyCode": "$25,187",
			"Price": 956,
			"Width": 30,
			"Depth": 18,
			"Height": 3,
			"DimUnit": "cm"
		}
		
	
		]
	};

var jsonmodel = new sap.ui.model.json.JSONModel();
jsonmodel.setData(data);
this.getView().byId("idProductsTable").setModel(jsonmodel);


				
			},
			onAfterRendering : function()
			{
				
				
					var oVizFrame1 = this.getView().byId("idcolumn");

			//      2.Create a JSON Model and set the data
		
		     
		     	var oVizFrame = this.getView().byId("idpiechart");

			//      2.Create a JSON Model and set the data
			var jsonModelPieChart = new sap.ui.model.json.JSONModel();
			var data = {
				'Account': [{
						"Category": "Fridge",
						"Value": "10"
					}, {
						"Category": "Cooking appliances",
						"Value": "25"
					},
					{
						"Category": "Lights",
						"Value": "30"
					}, {
						"Category": "AC",
						"Value": "35"
					}
				
				]
			};

			jsonModelPieChart.setData(data);
			
				var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: 'Category',
					value: "{Category}"
				}],

				measures: [{
					name: 'Value',
					value: '{Value}'
				}],

				data: {
					path: "/Account"
				}
			});
						oVizFrame.setVizType('pie');

			oVizFrame.setDataset(oDataset);
			oVizFrame.setModel(jsonModelPieChart);
			
				oVizFrame.setVizProperties({
				title: {
					text: "Device Consumption"
				},
				plotArea: {
					colorPalette: d3.scale.category20().range(),
					drawingEffect: "glossy"
				}
			});

			var feedSize = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "size",
					'type': "Measure",
					'values': ["Value"]
				}),
				feedColor = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "color",
					'type': "Dimension",
					'values': ["Category"]
				});
			oVizFrame.addFeed(feedSize);
			oVizFrame.addFeed(feedColor);
		
		  

			var oModel1 = new sap.ui.model.json.JSONModel();
			var data1 = {
				'Population': [{
					"Month": "Jan",
					"Value": "140"
				}, {
					"Month": "Feb",
					"Value": "130"
				}, {
					"Month": "Mar",
					"Value": "300"
				}, {
					"Month": "Apr",
					"Value": "200"
				}, {
					"Month": "May",
					"Value": "200"
				},
				{
					"Month": "Jun",
					"Value": "140"
				}, {
					"Month": "Jul",
					"Value": "150"
				}, {
					"Month": "Aug",
					"Value": "160"
				}, {
					"Month": "Sep",
					"Value": "170"
				}, {
					"Month": "Oct",
					"Value": "120"
				},
				{
					"Month": "NoV",
					"Value": "130"
				}, {
					"Month": "Dec",
					"Value": "135"
				}
				]
			};
			oModel1.setData(data1);

			//      3. Create Viz dataset to feed to the data to the graph
		

			var oDataset1 = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: 'Month',
					value: "{Month}"
				}],

				measures: [{
					name: 'Payment',
					value: '{Value}'
				}],

				data: {
					path: "/Population"
				}
			});
			oVizFrame1.setDataset(oDataset1);
			oVizFrame1.setModel(oModel1);
			oVizFrame1.setVizType('column');

			//      4.Set Viz properties
		

			oVizFrame1.setVizProperties({
				title: {
					text: "Last 12 months payments"
				},
				plotArea: {
					colorPalette: d3.scale.category20().range()
				}
			});

			var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Payment"]
				}),
				feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "categoryAxis",
					'type': "Dimension",
					'values': ["Month"]
				});
			oVizFrame1.addFeed(feedValueAxis);
			oVizFrame1.addFeed(feedCategoryAxis);
			}
	});
});